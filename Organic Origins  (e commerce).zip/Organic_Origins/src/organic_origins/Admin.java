package organic_origins;

import javax.swing.*;

import java.sql.*;
import java.awt.event.*;
import java.awt.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Admin extends JFrame {

    private JPanel contentPane;

    static Connection con() {
        try {
            String jdbcurl = "jdbc:postgresql://localhost:5432/Organic Origins";
            String username = "postgres";
            String password = "Awesome7456";
            Connection connection = DriverManager.getConnection(jdbcurl, username, password);
        } catch (Exception e) {
            System.out.println("Connection failed: " + e);
        }
        return null;

    }

    public static void main(String[] args) {
        new Admin();
    }

    public Admin() {

        setBounds(100, 100, 626, 455);
        contentPane = new JPanel();
        setContentPane(contentPane);
        contentPane.setLayout(null);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("organic_origins/images\\a.jpg"));
        Image i3 = i1.getImage().getScaledInstance(626, 455, Image.SCALE_DEFAULT);
        ImageIcon i2 = new ImageIcon(i3);
        JLabel l1 = new JLabel(i2);
        l1.setBounds(0, 0, 626, 455);
        add(l1);

        JLabel l2 = new JLabel("ADMIN ");
        l2.setBounds(100, 30, 150, 50);
        l2.setFont(new Font("FORTE", Font.BOLD, 30));
        l2.setForeground(Color.blue);
        l1.add(l2);

        JButton btnNewCustomerForm = new JButton("Add Product");
        btnNewCustomerForm.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {

                new New_Product().setVisible(true);
                try {
                    //setVisible(false);
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }

        });
        btnNewCustomerForm.setBounds(160, 90, 150, 30);
        btnNewCustomerForm.setBackground(Color.BLACK);
        btnNewCustomerForm.setForeground(Color.WHITE);
        l1.add(btnNewCustomerForm);

        JButton btnNewButton = new JButton("Remove Product");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                try {
                    new Delete_Product().setVisible(true);
                    //setVisible(false);
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });
        btnNewButton.setBounds(220, 160, 150, 30);
        btnNewButton.setBackground(Color.BLACK);
        btnNewButton.setForeground(Color.WHITE);

        l1.add(btnNewButton);

        JButton btnNewButton_1 = new JButton("Update Product");
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    new Update_Product().setVisible(true);
//                    setVisible(false);
                } catch (Exception e1) {
                    e1.printStackTrace();
                }

            }
        });
        btnNewButton_1.setBounds(280, 230, 150, 30);
        btnNewButton_1.setBackground(Color.BLACK);
        btnNewButton_1.setForeground(Color.WHITE);

        l1.add(btnNewButton_1);

        JButton btnNewButton_2 = new JButton("View Orders");
        
        btnNewButton_2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {

                    //Employee em = new Employee();
                    //em.setVisible(true);
                    new ViewCartSajjad().setVisible(true);
                    //setVisible(false);

                } catch (Exception e1) {
                    e1.printStackTrace();
                }

            }
        });
        btnNewButton_2.setBounds(320, 300, 150, 30);
        btnNewButton_2.setBackground(Color.BLACK);
        btnNewButton_2.setForeground(Color.WHITE);

        l1.add(btnNewButton_2);

        /*
        btnManagerInfo.setBounds(10, 230, 200, 30);
        btnManagerInfo.setBackground(Color.BLACK);
        btnManagerInfo.setForeground(Color.WHITE);

        contentPane.add(btnManagerInfo);

        JButton btnNewButton_4 = new JButton("Check Out");
        btnNewButton_4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                CheckOut check;
                try {
                    check = new CheckOut();
                    check.setVisible(true);
                    setVisible(false);
                } catch (SQLException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
            }
        });
        btnNewButton_4.setBounds(10, 270, 200, 30);
        btnNewButton_4.setBackground(Color.BLACK);
        btnNewButton_4.setForeground(Color.WHITE);

        contentPane.add(btnNewButton_4);

        JButton btnNewButton_5 = new JButton("Update Check Status");
        btnNewButton_5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try{
                    UpdateCheck update = new UpdateCheck();
                    update.setVisible(true);
                    setVisible(false);
                }
                catch(Exception e1){
                    e1.printStackTrace();
                }
            }
        });
        btnNewButton_5.setBounds(10, 310, 200, 30);
        btnNewButton_5.setBackground(Color.BLACK);
        btnNewButton_5.setForeground(Color.WHITE);

        contentPane.add(btnNewButton_5);

        JButton btnNewButton_6 = new JButton("Update Room Status");
        btnNewButton_6.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try{
                    UpdateRoom room = new UpdateRoom();
                    room.setVisible(true);
                    setVisible(false);
                }catch(Exception s)
                {
                    s.printStackTrace();
                }
            }
        });
        btnNewButton_6.setBounds(10, 350, 200, 30);
        btnNewButton_6.setBackground(Color.BLACK);
        btnNewButton_6.setForeground(Color.WHITE);

        contentPane.add(btnNewButton_6);

        JButton btnPickUpSerice = new JButton("Pick up Service");
        btnPickUpSerice.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                try{
                    PickUp pick = new PickUp();
                    pick.setVisible(true);
                    setVisible(false);
                }
                catch(Exception e){
                    e.printStackTrace();
                }
            }
        });
        btnPickUpSerice.setBounds(10, 390, 200, 30);
        btnPickUpSerice.setBackground(Color.BLACK);
        btnPickUpSerice.setForeground(Color.WHITE);

        contentPane.add(btnPickUpSerice);

        JButton btnSearchRoom = new JButton("Search Room");
        btnSearchRoom.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    SearchRoom search = new SearchRoom();
                    search.setVisible(true);
                    setVisible(false);
                }
                catch (Exception ss){
                    ss.printStackTrace();
                }
            }
        });
        btnSearchRoom.setBounds(10, 430, 200, 30);
        btnSearchRoom.setBackground(Color.BLACK);
        btnSearchRoom.setForeground(Color.WHITE);

        contentPane.add(btnSearchRoom);*/
        JButton btnNewButton_7 = new JButton("Back");
        btnNewButton_7.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                try {
                    //new Login().setVisible(true);
                    setVisible(false);

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });
        btnNewButton_7.setBounds(10, 470, 200, 30);
        btnNewButton_7.setBackground(Color.BLACK);
        btnNewButton_7.setForeground(Color.WHITE);

        contentPane.add(btnNewButton_7);
        getContentPane().setBackground(Color.WHITE);

        setVisible(true);
    }
}
