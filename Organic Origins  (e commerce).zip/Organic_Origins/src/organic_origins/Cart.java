
package organic_origins;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import net.proteanit.sql.DbUtils;

public class Cart extends JFrame {

    private JPanel panel;
JTextField t1;
    private JButton b1,b2;


    public Cart() {

        setBackground(new Color(161, 64, 64));
        setBounds(500, 200, 600, 400);

        panel = new JPanel();
        panel.setBackground(new Color(255, 255, 255, 255));
        setContentPane(panel);
        panel.setLayout(null);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("organic_origins/images/cart.png"));
        Image i2 = i1.getImage().getScaledInstance(225,225,Image.SCALE_DEFAULT);
        ImageIcon i3 =  new ImageIcon(i2);
        JLabel l3 = new JLabel(i3);
        l3.setBounds(290,45,225,225);
        add(l3);


        JLabel label = new JLabel("CART");
        label.setBounds(170, 10, 200, 24);
        label.setFont(new Font("Cooper Black", Font.BOLD, 30));
        label.setForeground(Color.BLUE);
        panel.add(label);

        JLabel l1 = new JLabel("Product ");
        l1.setBounds(35, 79, 95, 24);
        l1.setFont(new Font("Times New Roman", Font.BOLD, 18));
        l1.setForeground(Color.BLACK);
        panel.add(l1);

        JLabel l2 = new JLabel("Price");
        l2.setBounds(124, 115, 95, 24);
        l2.setFont(new Font("Times New Roman", Font.BOLD, 18));
        l2.setForeground(Color.BLACK);
        panel.add(l2);
        b2 = new JButton();
        t1=new JTextField();
        t1.setBounds(250,145,150,25);
        panel.add(t1);
        b1 = new JButton("View Cart");

        b1.setForeground(new Color(255, 255, 255));
        b1.setBackground(new Color(30, 25, 30));
        b1.setBounds(144, 216, 115, 25);
        panel.add(b1);
        
        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try{
                    System.out.println("Done 2");
                   SQLCON c = new SQLCON();
                   String val = t1.getText();
                   String val1;
                   String val2;
                    String query = "Select  productname, price FROM cart WHERE customer_customer_id = " + val;
                    ResultSet rs = c.s.executeQuery(query );
                    while(rs.next()){
                       
                val1 = rs.getString(1);
                val2 = rs.getString(2);
                l1.setText(val1);
                l2.setText(val2);
                
                    }
                    System.out.println("Done");
                }
                catch(Exception e1){
                    e1.printStackTrace();
                }
            }

        });
        
        JLabel l4 = new JLabel("Customer_ID");
        l4.setBounds(124, 145, 115, 24);
        l4.setFont(new Font("Times New Roman", Font.BOLD, 18));
        l4.setForeground(Color.BLACK);
        panel.add(l4);







        JPanel panel2 = new JPanel();
        panel2.setBackground(new Color(255, 255, 255, 255));
        panel2.setBounds(24, 40, 434, 263);
        panel.add(panel2);
    }

    /*public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == b1){
            Boolean status = false;
            try {
                conn con = new conn();
                String sql = "select * from account where username=? and password=?";
                PreparedStatement st = con.c.prepareStatement(sql);

                st.setString(1, textField.getText());
                st.setString(2, passwordField.getText());

                ResultSet rs = st.executeQuery();
                if (rs.next()) {
                    this.setVisible(false);
                    new Loading().setVisible(true);
                } else
                    JOptionPane.showMessageDialog(null, "Invalid Login...!.");

            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
        if(ae.getSource() == b2){
            setVisible(false);
            Signup su = new Signup();
            su.setVisible(true);
        }
        if(ae.getSource() == b3){
            setVisible(false);
            Forgot forgot = new Forgot();
            forgot.setVisible(true);
        }
    }*/

    public static void main(String[] args) {
        new Cart().setVisible(true);
    }

}
