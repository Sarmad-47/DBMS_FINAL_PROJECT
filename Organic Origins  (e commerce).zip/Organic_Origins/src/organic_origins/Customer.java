package organic_origins;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.JTable;
import net.proteanit.sql.DbUtils;

public class Customer extends JFrame {
  private JTable table;
    private JPanel panel;
   private JTextField t1, t2, t3, t4, t5,t6,t7,t8;
    private JPasswordField passwordField;
    private JButton b1, b2, b3;

    public Customer() {

        setBackground(new Color(221, 64, 64));
        setBounds(900, 500, 1300, 1000);

        panel = new JPanel();
        panel.setBackground(new Color(30, 25, 249, 214));
        setContentPane(panel); 
        panel.setLayout(null);
        
         table = new JTable();
     table.setBounds(500,40,600,300);

        JLabel label = new JLabel("CUSTOMER");
        label.setBounds(170, 10, 200, 24);
        label.setFont(new Font("Cooper Black", Font.BOLD, 30));
        label.setForeground(Color.white);
        panel.add(label);

//        JLabel l1 = new JLabel("label1 ");
//        l1.setBounds(124, 59, 95, 24);
//        l1.setForeground(Color.white);
//        panel.add(l1);
//
//        JLabel l2 = new JLabel("label2");
//        l2.setBounds(124, 89, 95, 24);
//        l2.setForeground(Color.white);
//        panel.add(l2);
//
//        JLabel l3 = new JLabel("label3");
//        l3.setBounds(124, 119, 95, 24);
//        l3.setForeground(Color.WHITE);
//        panel.add(l3);

        JLabel l4 = new JLabel("Product_ID");
        l4.setBounds(124, 149, 95, 24);
        l4.setForeground(Color.white);
        panel.add(l4);

        JLabel l5 = new JLabel("Customer_ID");
        l5.setBounds(124, 179, 95, 24);
        l5.setForeground(Color.white);
        panel.add(l5);
        
        t6 = new JTextField();
        t6.setBounds(210, 179, 157, 20);
        panel.add(t6);
        
        t7 = new JTextField();
        t7.setBounds(210, 149, 157, 20);
        panel.add(t7);
        
//        t1 = new JTextField();
//        t1.setBounds(210, 149, 157, 20);
//        panel.add(t1);
        
//       t2 = new JTextField();
//        t2.setBounds(210, 149, 157, 20);
//        panel.add(t2);
//        
//           t3 = new JTextField();
//        t3.setBounds(210, 149, 157, 20);
//        panel.add(t3);
//        
//           t4 = new JTextField();
//        t4.setBounds(210, 149, 157, 20);
//        panel.add(t4);
//
//        t5 = new JTextField();
//        t5.setBounds(210, 149, 157, 20);
//        panel.add(t5);
//        
        
        
//          t8 = new JTextField();
//        t8.setBounds(210, 149, 157, 20);
//        panel.add(t8);
        
        


        /*JLabel l3 = new JLabel("");
        l3.setBounds(377, 79, 46, 34);
        panel.add(l3);

        JLabel l4 = new JLabel("");
        l4.setBounds(377, 124, 46, 34);
        panel.add(l3);*/
        b1 = new JButton("View Products");
      //  b1.addActionListener((ActionListener) this);
                
        
       b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            try{
                   SQLCON c = new SQLCON();
                    String displayCitysql = "Select * from product";
                    ResultSet rs = c.s.executeQuery(displayCitysql );
                   table.setModel(DbUtils.resultSetToTableModel(rs));

      panel.add(table);                 
                }
                catch(Exception e1){
                    e1.printStackTrace();
                }
            }

        });


        b1.setForeground(new Color(46, 139, 87));
        b1.setBackground(new Color(250, 250, 210));
        b1.setBounds(149, 216, 120, 39);
        panel.add(b1);

        b2 = new JButton("Add To Cart");
        //b2.addActionListener(this);
        b2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    System.out.println("dbf");
                    SQLCON c = new SQLCON();
                    String  product_product_id = t6.getText();
                    String customer_customer_id = t7.getText();
             //       String cart_id = "Select cart_id FROM cart WHERE cart_id=(SELECT max(cart_id) FROM cart)";
             int cart_idI = 0;
             String cart_id1 = null;
                    ResultSet rs1 = c.s.executeQuery("Select cart_id FROM cart WHERE cart_id=(SELECT max(cart_id) FROM cart)");
                    while (rs1.next()) {
                    cart_idI = rs1.getInt(1);
                    }
                    //cart_idI = Integer.parseInt(cart_id1);
                    
                    int product_id = Integer.parseInt(t7.getText());
                    int customer_id = Integer.parseInt(t6.getText());
                    cart_idI++;
                    String cart_idS =  cart_idI+"";
                    System.out.println(cart_idI);
//                    String product_nameQ = "Select productname FROM product WHERE product.product_id = " + product_id; 
//                    String priceQ = "Select price FROM product WHERE product.product_id= " + product_id; 
//                    String totalQ = "Select total FROM product WHERE product.product_id= " + product_id; 
                    int product_admin_admin_id = 78601; 
                    int qty = 1;
                    String product_name = null;
                    int price = 0;
                    int total = 0;
                    String payment_type = "COD";
                    int product_category_id = 0;  
                    System.out.println(product_id+","+customer_id);
                    //c.s.executeUpdate(total);
                    ResultSet rs2 = c.s.executeQuery("SELECT price, product_name, category_category_id FROM product WHERE product.product_id = " + product_id);
                    while(rs2.next()){
                        product_category_id = rs2.getInt(3);
                        price = rs2.getInt(1);
                        total = rs2.getInt(1);
                        product_name = rs2.getString(2);
                    }
                    
//String admin_id = t5.getText();
                    String str = "INSERT INTO cart values( '" + cart_idI + "', '" + product_name + "', '" + price + "','" + qty + "', '" + total + "', '" +product_id + "','" + product_category_id + "', '" +payment_type + "','" +customer_id + "','" +product_admin_admin_id +"')";
                    System.out.println("Entered ");

                    c.s.executeUpdate(str);
                    JOptionPane.showMessageDialog(null, " Successfully Added to Cart");
                    
//                    ResultSet rs  = stmt.executeQuery("SELECT * from product ");
//            String query = "DELETE from product\n" +
//"WHERE product_id = " + id;
//                            PreparedStatement S=mycon.prepareStatement(query);
//                            S.execute();
//            System.out.println("DELETED"); 
//            JOptionPane.showMessageDialog(null, "Product Deleted");
        
                    
                    

                } catch (SQLException ee) {
                    System.out.println(ee);
                }
            }
        });

        b2.setForeground(new Color(139, 69, 19));
        b2.setBackground(new Color(255, 235, 205));
        b2.setBounds(296, 216, 113, 39);
        panel.add(b2);

        b3 = new JButton("See Total Products");
        //b3.addActionListener(this);
        
         JLabel l3 = new JLabel();
         l3.setFont(new Font("Tahoma",Font.BOLD,35));
         l3.setForeground(Color.white);
        l3.setBounds(200, 70, 500, 600);
        
        panel.add(l3);
        
        
        b3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    System.out.println("dbf");
                    SQLCON c = new SQLCON();
        
                    ResultSet rs1 = c.s.executeQuery("SELECT count(product_id) from product");
                    while (rs1.next()) {
                       l3 .setText(rs1.getString(1));
  
                    }
                    //cart_idI = Integer.parseInt(cart_id1);
   
                    

                } catch (Exception ee) {
                    System.out.println(ee);
                }
            }
        });

          

        b3.setForeground(new Color(205, 92, 92));
        b3.setBackground(new Color(253, 245, 230));
        b3.setBounds(199, 266, 179, 39);
        panel.add(b3);

        JPanel panel2 = new JPanel();
        panel2.setBackground(new Color(3, 19, 94, 255));
        panel2.setBounds(24, 40, 434, 263);
        panel.add(panel2);
    }

    /*public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == b1){
            Boolean status = false;
            try {
                conn con = new conn();
                String sql = "select * from account where username=? and password=?";
                PreparedStatement st = con.c.prepareStatement(sql);

                st.setString(1, textField.getText());
                st.setString(2, passwordField.getText());

                ResultSet rs = st.executeQuery();
                if (rs.next()) {
                    this.setVisible(false);
                    new Loading().setVisible(true);
                } else
                    JOptionPane.showMessageDialog(null, "Invalid Login...!.");

            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
        if(ae.getSource() == b2){
            setVisible(false);
            Signup su = new Signup();
            su.setVisible(true);
        }
        if(ae.getSource() == b3){
            setVisible(false);
            Forgot forgot = new Forgot();
            forgot.setVisible(true);
        }
    }*/
    public static void main(String[] args) {
        new Customer().setVisible(true);
    }

}
