
package organic_origins;



import java.awt.Image;
import javax.swing.ImageIcon;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

public class MainWindow extends JFrame
{
    public MainWindow()
    {
        getContentPane().setForeground(Color.BLUE);
        getContentPane().setBackground(Color.WHITE);
        setTitle("Organic Origins");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200,800);

        getContentPane().setLayout(null);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("organic_origins/images/main.jpg"));
        Image i2 = i1.getImage().getScaledInstance(1200,800,Image.SCALE_DEFAULT);
        ImageIcon i3 =  new ImageIcon(i2);
        JLabel l3 = new JLabel(i3);
        l3.setBounds(0,0,1200,800);
        add(l3);




        JButton b2 = new JButton("Admin");
        b2.setFont(new Font("Times New Roman", Font.BOLD, 14));
        b2.setBounds(280,235,95,29);
        b2.setBackground(Color.black);
        b2.setForeground(Color.white);
        b2.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                try
                {
                    new Admin().setVisible(true);
                }
                catch(Exception e1)
                {
                    e1.printStackTrace();
                }
            }

        });
        l3.add(b2);

        JButton b3 = new JButton("Customer");
        b3.setFont(new Font("Times New Roman", Font.BOLD, 14));
        b3.setBounds(400,235,95,29);
        b3.setBackground(Color.black);
        b3.setForeground(Color.white);
        b3.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                try
                {
                    new Customer().setVisible(true);
                }
                catch(Exception e1)
                {
                    e1.printStackTrace();
                }
            }

        });
        l3.add(b3);

        JLabel l1=new JLabel("Organic Origins");
        l1.setFont(new Font("Forte",Font.BOLD, 50));
        l1.setBounds(20,15,600,300);
        l1.setForeground(Color.white);
        l3.add(l1);


        setVisible(true);

        /*JLabel l2=new JLabel(" BY Zeeshan & Zahra");
        l2.setFont(new Font("Fo",Font.BOLD, 35));
        l2.setBounds(500,50,600,300);
        l2.setForeground(Color.white);
        l3.add(l2);*/


        setVisible(true);
    }

    public static void main(String[] args)
    {
        new MainWindow().setVisible(true);
    }


}
