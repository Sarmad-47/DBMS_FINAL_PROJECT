package organic_origins;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;

public class New_Product extends JFrame { //implements ActionListener{

    private JPanel contentPane;
    private JTextField t1, t2, t3, t4, t5;
    private JComboBox comboBox, comboBox_1, comboBox_2, comboBox_3;
    JButton b1, b2;
    Choice c1;

    public static void main(String[] args) {
        new New_Product().setVisible(true);
    }

    public New_Product() {
        setBounds(450, 200, 750, 450);
        contentPane = new JPanel();
        setContentPane(contentPane);
        contentPane.setLayout(null);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("organic_origins/images/p.png"));
        Image i3 = i1.getImage().getScaledInstance(256, 256, Image.SCALE_DEFAULT);
        ImageIcon i2 = new ImageIcon(i3);
        JLabel l15 = new JLabel(i2);
        l15.setBounds(400, 40, 256, 256);
        add(l15);

        JLabel l10 = new JLabel("ADD A PRODUCT");
        l10.setFont(new Font("Forte", Font.BOLD, 30));
        l10.setBounds(260, 10, 300, 50);
        l10.setForeground(Color.black);
        contentPane.add(l10);

        JLabel l1 = new JLabel("Product_ID");
        l1.setForeground(new Color(25, 25, 112));
        l1.setFont(new Font("Tahoma", Font.BOLD, 14));
        l1.setBounds(64, 70, 102, 22);
        contentPane.add(l1);

        t1 = new JTextField();
        t1.setBounds(174, 70, 156, 20);
        contentPane.add(t1);

        JLabel l2 = new JLabel("Product Name");
        l2.setForeground(new Color(25, 25, 112));
        l2.setFont(new Font("Tahoma", Font.BOLD, 14));
        l2.setBounds(64, 110, 102, 22);
        contentPane.add(l2);

        t2 = new JTextField();
        t2.setBounds(174, 110, 156, 20);
        contentPane.add(t2);

        JLabel l3 = new JLabel("Price");
        l3.setForeground(new Color(25, 25, 112));
        l3.setFont(new Font("Tahoma", Font.BOLD, 14));
        l3.setBounds(64, 150, 102, 22);
        contentPane.add(l3);

        t3 = new JTextField();
        t3.setBounds(174, 150, 156, 20);
        contentPane.add(t3);

        JLabel l4 = new JLabel("Category_ID");
        l4.setForeground(new Color(25, 25, 112));
        l4.setFont(new Font("Tahoma", Font.BOLD, 14));
        l4.setBounds(64, 190, 102, 22);
        contentPane.add(l4);

        t4 = new JTextField();
        t4.setBounds(174, 190, 156, 20);
        contentPane.add(t4);

        JLabel l5 = new JLabel("Admin_ID");
        l5.setForeground(new Color(25, 25, 112));
        l5.setFont(new Font("Tahoma", Font.BOLD, 14));
        l5.setBounds(64, 230, 102, 22);
        contentPane.add(l5);

        t5 = new JTextField();
        t5.setBounds(174, 230, 156, 20);
        contentPane.add(t5);

        b1 = new JButton("Add");
        //b1.addActionListener(this);
        b1.setBounds(64, 321, 111, 33);
        b1.setBackground(Color.BLACK);
        b1.setForeground(Color.WHITE);
        contentPane.add(b1);
        
         b2 = new JButton("Back");
        //b2.addActionListener(this);
        b2.setBounds(198, 321, 111, 33);
        b2.setBackground(Color.BLACK);
        b2.setForeground(Color.WHITE);
        contentPane.add(b2);
        
         contentPane.setBackground(Color.WHITE);

        //b1.setVisible(true);
        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    System.out.println("dbf");
                    SQLCON c = new SQLCON();
                    String product_id = t1.getText();
                    String name = t2.getText();
                    String price = t3.getText();
                    String category_id = t4.getText();
                    String admin_id = t5.getText();
                    String str = "INSERT INTO product values( '" + product_id + "', '" + name + "', '" + price + "','" + category_id + "', '" + admin_id + "')";
                    System.out.println("dgdbbf");

                    /*String jdbcurl = "jdbc:postgresql://localhost:5432/Organic Origins";
    String username = "postgres";
    String password = "Awesome7456";
    //ResultSet rs1;
    //ResultSet rs2;
    Connection connection = DriverManager.getConnection(jdbcurl, username, password);
Statement stmt = connection.createStatement();  */
                    //s = connection.createStatement(str); 
                    c.s.executeUpdate(str);
                    JOptionPane.showMessageDialog(null, " Successfully Added");
                    //this.setVisible(false);

                } catch (Exception ee) {
                    System.out.println(ee);
                }
            }
        });

    }

    //   public void actionPerformed(ActionEvent ae){
    //   try{
    //         if(ae.getSource() == b1){
//                try{
//                                System.out.println("dbf");
//                    SQLCON c = new SQLCON();
//                    String product_id = t1.getText();
//                    String name = t2.getText();
//                    String price = t3.getText();
//                    String category_id  = t4.getText();
//                    String admin_id = t5.getText();
//                    String str = "INSERT INTO product values( '"+product_id+"', '"+name+"', '"+price+"','"+category_id+"', '"+admin_id+"')";
//                    System.out.println("dgdbbf");
//
//                    /*String jdbcurl = "jdbc:postgresql://localhost:5432/Organic Origins";
//    String username = "postgres";
//    String password = "Awesome7456";
//    //ResultSet rs1;
//    //ResultSet rs2;
//    Connection connection = DriverManager.getConnection(jdbcurl, username, password);
//Statement stmt = connection.createStatement();  */ 
// //s = connection.createStatement(str); 
//                    c.s.executeUpdate(str);
//                    JOptionPane.showMessageDialog(null, " Successfully Added");
//                    this.setVisible(false);
//
//                }catch(Exception ee){
//                    System.out.println(ee);
//                }
    //        else if(ae.getSource() == b2){
    //          this.setVisible(false);
    //    }
    //}catch(Exception eee){
    //               System.out.println(eee);
}
//}
//}

