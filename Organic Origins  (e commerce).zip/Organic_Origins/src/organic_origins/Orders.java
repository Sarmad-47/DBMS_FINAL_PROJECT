
package organic_origins;



import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.sql.ResultSet;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Orders extends JFrame implements ActionListener{

    JLabel l1,l2, l4;
    JTextField t1;
    JPasswordField t2;
    JButton b1,b2;

    Orders(){

        super("Delete A Product");

        setLayout(null);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("organic_origins/images/order.jpg"));
        Image i2 = i1.getImage().getScaledInstance(450,500,Image.SCALE_DEFAULT);
        ImageIcon i3 =  new ImageIcon(i2);
        JLabel l3 = new JLabel(i3);
        l3.setBounds(00,00,450,500);
        add(l3);

        l4 = new JLabel("ORDERS");
        l4.setBounds(125,30,300,50);
        l4.setFont(new Font("Cooper Black", Font.BOLD, 40));
        l4.setForeground(Color.red);
        l3.add(l4);

        l1 = new JLabel("Orders");
        l1.setBounds(120,100,150,30);
        l1.setFont(new Font("Comic Sans MS", Font.BOLD, 20));
        l1.setForeground(Color.blue);
        l3.add(l1);


        b1 = new JButton("Delete");
        b1.setBounds(145,240,115,25);
        b1.setFont(new Font("Cambria",Font.BOLD,15));
        b1.addActionListener(this);
        b1.setBackground(Color.GRAY);
        b1.setForeground(Color.BLACK);
        l3.add(b1);

        b2=new JButton("Cancel");
        b2.setBounds(145,300,115,25);
        b2.setFont(new Font("Cambria",Font.BOLD,15));
        b2.setBackground(Color.GRAY);
        b2.setForeground(Color.BLACK);
        l3.add(b2);

        b2.addActionListener(this);


        getContentPane().setBackground(Color.lightGray);

        setVisible(true);
        setSize(450,450);
        setLocation(400,150);

    }

    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==b1){
            try{
                /*conn c1 = new conn();
                String u = t1.getText();
                String v = t2.getText();

                String q = "select * from login where username='"+u+"' and password='"+v+"'";

                ResultSet rs = c1.s.executeQuery(q);
                if(rs.next()){
                    JOptionPane.showMessageDialog(null, "login successfull");
                    new Employee_Info().setVisible(true);
                    setVisible(false);
                }else{
                    JOptionPane.showMessageDialog(null, "Invalid login");
                    //. setVisible(false);
                }*/
            }catch(Exception e){
                e.printStackTrace();
            }
        }else if(ae.getSource()==b2){
            System.exit(0);
        }
    }
    public static void main(String[] arg){

        new Orders().setVisible(true);
    }
    
}

