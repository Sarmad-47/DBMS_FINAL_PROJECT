package organic_origins;

import java.sql.DriverManager;
import java.sql.*;
import javax.swing.*;

public class SQLCON {
    
    Connection con;
    Statement s;
    public SQLCON(){
        try{
            //Class.forName("com.mysql.jdbc.Driver");
             String jdbcurl = "jdbc:postgresql://localhost:5432/Organic Origins";
    String username = "postgres";
    String password = "Awesome7456";
    ResultSet rs1;
    ResultSet rs2;
    Connection connection = DriverManager.getConnection(jdbcurl, username, password);

            s =connection.createStatement();

            System.out.println("Done");

        }catch(Exception e){
            System.out.println(e);
        }
    }
    
    
    public static void main(String[] args) {
        
          Connection con;
    Statement s;
      try{
            //Class.forName("com.mysql.jdbc.Driver");
             String jdbcurl = "jdbc:postgresql://localhost:5432/Organic Origins";
    String username = "postgres";
    String password = "Awesome7456";
    ResultSet rs1;
    ResultSet rs2;
    Connection connection = DriverManager.getConnection(jdbcurl, username, password);

            s =connection.createStatement();

            System.out.println("Done");

        }catch(Exception e){
            System.out.println(e);
        }
    }
}

    
    
    
    

