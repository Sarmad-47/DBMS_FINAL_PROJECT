
package organic_origins;


import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.sql.ResultSet;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Update_Product extends JFrame implements ActionListener{

    JLabel l1,l2, l4;
    JTextField t1, t2;
    JButton b1,b2;

    Update_Product(){

        super("UPDATE A PRODUCT");

        setLayout(null);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("organic_origins/images/update.jpg"));
        Image i2 = i1.getImage().getScaledInstance(450,500,Image.SCALE_DEFAULT);
        ImageIcon i3 =  new ImageIcon(i2);
        JLabel l3 = new JLabel(i3);
        l3.setBounds(00,00,450,500);
        add(l3);

        l4 = new JLabel("UPDATE A PRODUCT");
        l4.setBounds(105,30,300,50);
        l4.setFont(new Font("Forte", Font.BOLD, 22));
        l4.setForeground(Color.red);
        l3.add(l4);

        l1 = new JLabel("New Price");
        l1.setBounds(100,90,100,30);
        l1.setFont(new Font("Comic Sans MS", Font.BOLD, 15));
        l1.setForeground(Color.white);
        l3.add(l1);

        l2 = new JLabel("Product_ID");
        l2.setBounds(100,160,100,30);
        l2.setFont(new Font("Comic Sans MS", Font.BOLD, 15));
        l2.setForeground(Color.white);
        l3.add(l2);

        t1=new JTextField();
        t1.setBounds(135,125,150,25);
        l3.add(t1);

        t2=new JTextField();
        t2.setBounds(135,195,150,25);
        l3.add(t2);




        b1 = new JButton("Update");
        b1.setBounds(145,260,115,25);
        b1.setFont(new Font("Cambria",Font.BOLD,15));
        //b1.addActionListener(this);
        b1.setBackground(Color.GRAY);
        b1.setForeground(Color.BLACK);
        
        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    System.out.println("dbf");
                    SQLCON c = new SQLCON();
                    //String product_id = t1.getText();
                    String newPrice = t1.getText();
                    String id = t2.getText();
                    //String category_id = t4.getText();
                    //String admin_id = t5.getText();
                    String str  = "UPDATE product\n" +
"SET price = " + newPrice+
"WHERE product_id = "+id;
                    System.out.println("Updated ");

                    c.s.executeUpdate(str);
                    JOptionPane.showMessageDialog(null, " Successfully updated");
                    
//                    ResultSet rs  = stmt.executeQuery("SELECT * from product ");
//            String query = "DELETE from product\n" +
//"WHERE product_id = " + id;
//                            PreparedStatement S=mycon.prepareStatement(query);
//                            S.execute();
//            System.out.println("DELETED"); 
//            JOptionPane.showMessageDialog(null, "Product Deleted");
        
                    
                    

                } catch (Exception ee) {
                    System.out.println(ee);
                }
            }
        });
        
        l3.add(b1);

        b2=new JButton("Cancel");
        b2.setBounds(145,310,115,25);
        b2.setFont(new Font("Cambria",Font.BOLD,15));
        b2.setBackground(Color.GRAY);
        b2.setForeground(Color.BLACK);
        l3.add(b2);

        


        getContentPane().setBackground(Color.lightGray);

        setVisible(true);
        setSize(450,450);
        setLocation(400,150);

    }

    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==b1){
            try{
                /*conn c1 = new conn();
                String u = t1.getText();
                String v = t2.getText();

                String q = "select * from login where username='"+u+"' and password='"+v+"'";

                ResultSet rs = c1.s.executeQuery(q);
                if(rs.next()){
                    JOptionPane.showMessageDialog(null, "login successfull");
                    new Employee_Info().setVisible(true);
                    setVisible(false);
                }else{
                    JOptionPane.showMessageDialog(null, "Invalid login");
                    //. setVisible(false);
                }*/
            }catch(Exception e){
                e.printStackTrace();
            }
        }else if(ae.getSource()==b2){
            System.exit(0);
        }
    }
    public static void main(String[] arg){

        new Update_Product().setVisible(true);
    }
}

