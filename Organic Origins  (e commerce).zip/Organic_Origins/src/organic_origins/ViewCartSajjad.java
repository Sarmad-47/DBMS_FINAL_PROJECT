
package organic_origins;

import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.*;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ViewCartSajjad extends JFrame {
    private JTable table;
    private JTextField textField;        
    private JPanel panel;
  
      JLabel l1,l2, l4,I3;
    JTextField t1;
    JPasswordField t2;
    JButton b1,b2;
    
    
   public static void main(String[] args)  {
                    // ViewCartSajjad frame = new  ViewCartSajjad();
                    //frame.setVisible(true);
                    try{
                    new ViewCartSajjad().setVisible(true);
                    }
                    catch(Exception e){
                        System.out.println(e);
                    }
    }
    
    
    public ViewCartSajjad() throws SQLException{

  setBackground(new Color(161, 64, 64));
        setBounds(500, 200, 600, 400);

        panel = new JPanel();
        panel.setBackground(new Color(255, 255, 255, 255));
        setContentPane(panel);
        panel.setLayout(null);
        //ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("organic_origins/images/showingcart.jpg"));
        //Image i2 = i1.getImage().getScaledInstance(225,225,Image.SCALE_DEFAULT);
       // ImageIcon i3 =  new ImageIcon(i2);
      //  JLabel l3 = new JLabel(i3);
        //l3.setBounds(290,45,225,225);
        //panel.add(l3);

 JLabel label = new JLabel("CART");
        label.setBounds(200, 5, 200, 24);
        label.setFont(new Font("Cooper Black", Font.BOLD, 30));
        label.setForeground(Color.BLUE);
        panel.add(label);
        
     table = new JTable();
     table.setBounds(20,30,600,300);
      
      
        JButton btnLoadData = new JButton("Load Data");
        
          btnLoadData.setBounds(145,310,115,25);
      btnLoadData.setFont(new Font("Cambria",Font.BOLD,15));
        btnLoadData.setBackground(Color.GRAY);
        btnLoadData.setForeground(Color.BLACK);
        panel.add(btnLoadData);
        btnLoadData.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try{
                   SQLCON c = new SQLCON();
                    String displayCitysql = "Select * from cart";
                    ResultSet rs = c.s.executeQuery(displayCitysql );
                    table.setModel(DbUtils.resultSetToTableModel(rs));

      panel.add(table);                 
                }
                catch(Exception e1){
                    e1.printStackTrace();
                }
            }

        });
        

       getContentPane().setBackground(Color.WHITE);

    }

}