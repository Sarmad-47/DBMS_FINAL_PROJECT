package organic_origins;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.sql.ResultSet;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class login extends JFrame  {

    JLabel l1, l2, l4;
    JTextField t1;
    JPasswordField t2;
    JButton b1, b2;

    login() {

        super("LOGIN");

        setLayout(null);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("organic_origins/images/loginb.jpg"));
        Image i2 = i1.getImage().getScaledInstance(450, 500, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l3 = new JLabel(i3);
        l3.setBounds(00, 00, 450, 500);
        add(l3);

        l4 = new JLabel("ORGANIC ORIGIN");
        l4.setBounds(115, 30, 300, 50);
        l4.setFont(new Font("ALGERIAN", Font.BOLD, 20));
        l4.setForeground(Color.white);
        l3.add(l4);

        l1 = new JLabel("Username");
        l1.setBounds(100, 90, 100, 30);
        l1.setFont(new Font("Comic Sans MS", Font.BOLD, 13));
        l1.setForeground(Color.red);
        l3.add(l1);

        l2 = new JLabel("Password");
        l2.setBounds(100, 160, 100, 30);
        l2.setFont(new Font("Comic Sans MS", Font.BOLD, 13));
        l2.setForeground(Color.red);
        l3.add(l2);

        t1 = new JTextField();
        t1.setBounds(135, 125, 150, 25);
        l3.add(t1);

        t2 = new JPasswordField();
        t2.setBounds(135, 195, 150, 25);
        l3.add(t2);

        b1 = new JButton("Login");
        b1.setBounds(145, 260, 115, 25);
        b1.setFont(new Font("Cambria", Font.BOLD, 15));
        //b1.addActionListener(this);
        
        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    System.out.println("dbf");
                    SQLCON c = new SQLCON();
                    String user = t1.getText();
                    String pass = t2.getText();
                    //String price = t3.getText();
                   //String category_id = t4.getText();
                    //String admin_id = t5.getText();
                    //String str = "select * from login where username='"+user+"' and login.passwords='"+pass+"'";
                          
                  

                    //c.s.executeUpdate(str);
//                    System.out.println("Logged In");
//                    JOptionPane.showMessageDialog(null, " Logged In");
                    
                    ResultSet rs = c.s.executeQuery("select * from login where username='"+user+"' and login.passwords='"+pass+"'");
    
                 
            // ResultSet rs = stmt.executeQuery("select * from login");
            if (rs.next()) {
                JOptionPane.showMessageDialog(null, "login successfull");
                //JOptionPane.showMessageDialog(null, rs.getString(1) + "  " + rs.getString(2));
                //new Employee_Info().setVisible(true);
                new MainWindow().setVisible(true);
                setVisible(false);
            } else {
                JOptionPane.showMessageDialog(null, "Invalid login");
                //. setVisible(false);
            }
                    
                    /*String jdbcurl = "jdbc:postgresql://localhost:5432/Organic Origins";
    String username = "postgres";
    String password = "Awesome7456";
    //ResultSet rs1;
    //ResultSet rs2;
    Connection connection = DriverManager.getConnection(jdbcurl, username, password);
Statement stmt = connection.createStatement();  */
                    //s = connection.createStatement(str); 
                    //this.setVisible(false);

                } catch (Exception ee) {
                    System.out.println(ee);
                }
            }
        });
        
        b1.setBackground(Color.GRAY);
        b1.setForeground(Color.BLACK);
        l3.add(b1);

        b2 = new JButton("Cancel");
        b2.setBounds(145, 310, 115, 25);
        b2.setFont(new Font("Cambria", Font.BOLD, 15));
        b2.setBackground(Color.GRAY);
        b2.setForeground(Color.BLACK);
        l3.add(b2);

        //b2.addActionListener(this);

        getContentPane().setBackground(Color.lightGray);

        setVisible(true);
        setSize(450, 450);
        setLocation(400, 150);

    }

//    public void actionPerformed(ActionEvent ae) {
//        if (ae.getSource() == b1) {
//            try {
//                /*conn c1 = new conn();
//                String u = t1.getText();
//                String v = t2.getText();
//
//                String q = "select * from login where username='"+u+"' and password='"+v+"'";
//
//                ResultSet rs = c1.s.executeQuery(q);
//                if(rs.next()){
//                    JOptionPane.showMessageDialog(null, "login successfull");
//                    new Employee_Info().setVisible(true);
//                    setVisible(false);
//                }else{
//                    JOptionPane.showMessageDialog(null, "Invalid login");
//                    //. setVisible(false);
//                }*/
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        } else if (ae.getSource() == b2) {
//            System.exit(0);
//        }
//    }

    public static void main(String[] arg) {

        new login().setVisible(true);
    }
}
